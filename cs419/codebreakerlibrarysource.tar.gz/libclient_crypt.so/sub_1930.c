signed __int64 __fastcall sub_1930(__int64 a1, unsigned __int64 a2)
{
  __int64 v2; // rax
  char v4; // [rsp+0h] [rbp-38h]
  char v5; // [rsp+1h] [rbp-37h]
  char v6; // [rsp+2h] [rbp-36h]
  char v7; // [rsp+3h] [rbp-35h]
  char v8; // [rsp+4h] [rbp-34h]
  char v9; // [rsp+5h] [rbp-33h]
  char v10; // [rsp+6h] [rbp-32h]
  char v11; // [rsp+7h] [rbp-31h]
  char v12; // [rsp+8h] [rbp-30h]
  char v13; // [rsp+9h] [rbp-2Fh]
  char v14; // [rsp+Ah] [rbp-2Eh]
  char v15; // [rsp+Bh] [rbp-2Dh]
  char v16; // [rsp+Ch] [rbp-2Ch]
  char v17; // [rsp+Dh] [rbp-2Bh]
  char v18; // [rsp+Eh] [rbp-2Ah]
  char v19; // [rsp+Fh] [rbp-29h]
  char v20; // [rsp+10h] [rbp-28h]
  char v21; // [rsp+11h] [rbp-27h]
  char v22; // [rsp+12h] [rbp-26h]
  char v23; // [rsp+13h] [rbp-25h]
  char v24; // [rsp+14h] [rbp-24h]
  char v25; // [rsp+15h] [rbp-23h]
  char v26; // [rsp+16h] [rbp-22h]
  char v27; // [rsp+17h] [rbp-21h]
  char v28; // [rsp+18h] [rbp-20h]
  char v29; // [rsp+19h] [rbp-1Fh]
  char v30; // [rsp+1Ah] [rbp-1Eh]
  char v31; // [rsp+1Bh] [rbp-1Dh]
  char v32; // [rsp+1Ch] [rbp-1Ch]
  char v33; // [rsp+1Dh] [rbp-1Bh]
  char v34; // [rsp+1Eh] [rbp-1Ah]
  char v35; // [rsp+1Fh] [rbp-19h]
  unsigned __int64 v36; // [rsp+28h] [rbp-10h]

  v36 = __readfsqword(0x28u);
  v2 = 0LL;
  if ( !a1 || a2 <= 0x20 )
    return 1LL;
  do
  {
    v4 = 90;
    v5 = 55;
    v6 = 76;
    v7 = 55;
    v8 = 52;
    v9 = 86;
    v10 = 69;
    v11 = 87;
    v12 = 82;
    v13 = 50;
    v14 = 74;
    v15 = 75;
    v16 = 86;
    v17 = 51;
    v18 = 89;
    v19 = 69;
    v20 = 74;
    v21 = 53;
    v22 = 51;
    v23 = 73;
    v24 = 74;
    v25 = 50;
    v26 = 68;
    v27 = 55;
    v28 = 72;
    v29 = 84;
    v30 = 78;
    v31 = 89;
    v32 = 72;
    v33 = 83;
    v34 = 67;
    v35 = 68;
    *(_BYTE *)(a1 + v2) = *(&v4 + v2);
    ++v2;
  }
  while ( v2 != 32 );
  return 0LL;
}