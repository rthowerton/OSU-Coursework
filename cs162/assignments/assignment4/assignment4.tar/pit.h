#ifndef PIT_HEADER
#define PIT_HEADER
class pit : public event{
   public:
      pit();
      void near();
};
#endif
