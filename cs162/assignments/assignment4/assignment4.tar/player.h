#ifndef PLAYER_HEADER
#define PLAYER_HEADER
struct player{
   int numArrows, pRow, pCol;
   bool hasGold;
};
#endif
