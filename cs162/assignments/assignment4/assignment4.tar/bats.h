#ifndef BATS_HEADER
#define BATS_HEADER
class bats : public event{
   public:
      bats();
      void near();
};
#endif
