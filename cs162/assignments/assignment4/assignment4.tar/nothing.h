#ifndef NOTHING_HEADER
#define NOTHING_HEADER
class nothing : public event{
   public:
      nothing();
      void near();
};
#endif
