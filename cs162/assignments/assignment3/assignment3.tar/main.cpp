/*
 * Program: off-brand zoo tycoon
 * Author: Ryan Howerton
 * Date: 5/8/2016
 * Description: play the great game of zoo tycoon, but dummed down and text based
 * Input: NA
 * Output: game
 */
#include <iostream>
using namespace std;
#include "zoo.h"

int main(){
   zoo myZoo;
   myZoo.playGame();
   return 0;
}
